format long e
10^8+10^-7
10^8+10^-8