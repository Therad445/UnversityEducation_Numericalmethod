p=poly(1:20);
roots(p);
p(2)=10^-7;
roots(p);