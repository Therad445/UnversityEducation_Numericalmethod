2^1023
2^2024
realmax
realmin