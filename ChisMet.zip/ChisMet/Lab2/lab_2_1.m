function [ res ] = lab2_1( x )
 
    res =  x.^5 - 19*x.^4 + 106*x.^3 - 70*x.^2 - 539*x - 343;
